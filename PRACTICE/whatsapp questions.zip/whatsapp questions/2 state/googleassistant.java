import java.util.*;
public interface googleassistant{
    public void command(Context context);
}