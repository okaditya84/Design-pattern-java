import java.util.*;
public interface iterator{
    public boolean hasNext();
    public Object next();
}