import java.util.*;
public interface transcontainer {
    public iterator getIterator();
}